
function sayHello() {
  document.getElementById('output').innerText = "Hello! I'm Pikdi AI, your free AI assistant.";
}
